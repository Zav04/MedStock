import flet as ft
from Pages import login_page


def main(page: ft.Page):
    page.favicon = "assets/Logo/Lateral/PNG/Logo.png"
    # page.window_icon = "assets/Logo/Lateral/PNG/Logo.png"
    login_page(page)


ft.app(target=main, assets_dir="assets", host="localhost", port=8000)
